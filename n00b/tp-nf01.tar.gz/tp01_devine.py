#!/usr/bin/env python
# -*- coding: utf-8 -*-

Ncoups=15
Nmax=1000

# Initialisations
n, nb_coup = 0, 0

# Prise de contact
nom=raw_input('Pour commencer, donner votre nom : \n')
prenom=raw_input('Votre prenom : \n')

# regle du jeu et tirage du nombre mystere
print("\nJe vais choisir un nombre entre 1 et " + str(Nmax) + ".\n...")

import random
nb_a_dev=random.randint(1, Nmax)

print("Voila, c'est fait; à vous de le deviner maintenant !")

while nb_coup < Ncoups and n!=nb_a_dev:
    n = int(raw_input("\nProposition ?\n"))
    nb_coup = nb_coup + 1

    if n < 1 or n > Nmax: print('On a dit entre 1 et 1000 !') 

    if n < nb_a_dev : print('Trop petit.')
    elif n > nb_a_dev : print('Trop grand.')

    if abs(n-nb_a_dev)==1: print('Mais ca brule !')

# Affichage des resultats
if n==nb_a_dev:
    print('Oui !, Bravo, %s %s,  vous avez trouve en %s coups.') % (
        nom, prenom, nb_coup)
    print('Le nombre etait effectivement %s.' % nb_a_dev)
else:
    print """Bon, ca va bien maintenant %s on jette l'eponge !
    J'avais choisi %s.
    Vous n'etes pas encore pret pour le Juste prix""", (nom, nb_a_dev)
  
        
